﻿// =====================================================================================
//  WEEK PLANNER  -  everything lives in this one file (Form1).
//  Works with a normal .NET Framework WinForms project (4.5 - 4.8), C# 7.3.
//  NuGet package needed: MailKit   (Install-Package MailKit)
//  If your project's namespace is not "WeekPlanner", just change the line below
//  (and in Form1.Designer.cs / Program.cs).
// =====================================================================================
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Media;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Win32;

namespace WeekPlanner
{
    public partial class Form1 : Form
    {
        // =================================================================== e-mail settings
        // Use a Gmail "App Password" (Google Account -> Security -> 2-Step Verification -> App passwords),
        // NOT your normal password.
        const string MailSender = "weekplannerapp@gmail.com";
        const string MailAppPass = "oheo tmkx dgfv xebm";
        const string MailRecipient = "besenskimatija5@gmail.com";

        static async Task SendEmailReminderAsync(string taskName, string notes, DateTime taskTime)
        {
            try
            {
                // Gmail needs TLS 1.2 (matters on older .NET Framework versions)
                System.Net.ServicePointManager.SecurityProtocol |= (System.Net.SecurityProtocolType)3072;

                string body = "🔔 Week Planner Reminder\n\n" +
                              "Task: " + taskName + "\n" +
                              "Time: " + taskTime.ToString("HH:mm") + "\n";
                if (!string.IsNullOrWhiteSpace(notes)) body += "\nNotes:\n" + notes + "\n";

                using (var msg = new System.Net.Mail.MailMessage())
                {
                    msg.From = new System.Net.Mail.MailAddress(MailSender, "Week Planner");
                    msg.To.Add(new System.Net.Mail.MailAddress(MailRecipient, "Me"));
                    msg.Subject = "🔔 Reminder: " + taskName;
                    msg.SubjectEncoding = Encoding.UTF8;
                    msg.Body = body;
                    msg.BodyEncoding = Encoding.UTF8;

                    using (var smtp = new System.Net.Mail.SmtpClient("smtp.gmail.com", 587))
                    {
                        smtp.EnableSsl = true;
                        smtp.DeliveryMethod = System.Net.Mail.SmtpDeliveryMethod.Network;
                        smtp.UseDefaultCredentials = false;
                        smtp.Credentials = new System.Net.NetworkCredential(MailSender, MailAppPass);
                        await smtp.SendMailAsync(msg);
                    }
                }
            }
            catch { /* no internet / wrong password: don't crash the planner */ }
        }

        // =================================================================== small classes
        public class Category
        {
            public string Id, CustomName;
            public int Rgb;
            public bool AsksSubject;
            public List<string> Subjects = new List<string>();
            public string Name { get { return string.IsNullOrWhiteSpace(CustomName) ? Tr("cat_" + Id) : CustomName; } }
            public Color Col { get { return Color.FromArgb(Rgb); } }
        }

        public class TaskItem
        {
            public string Id = Guid.NewGuid().ToString("N");
            public string Title = "", CategoryId, Subject = "", Notes = "";
            public DateTime Due = DateTime.Now, SnoozeUntil = DateTime.MinValue;
            public bool Done, RemindEnabled, Reminded;
            public int RemindAmount = 1, RemindUnit = 1;   // unit: 0 = minutes, 1 = hours, 2 = days

            public TimeSpan RemindOffset
            {
                get
                {
                    return RemindUnit == 0 ? TimeSpan.FromMinutes(RemindAmount)
                         : RemindUnit == 1 ? TimeSpan.FromHours(RemindAmount)
                         : TimeSpan.FromDays(RemindAmount);
                }
            }
            public DateTime RemindAt { get { return SnoozeUntil != DateTime.MinValue ? SnoozeUntil : Due - RemindOffset; } }
            public string ReminderShort()
            {
                return RemindAmount + " " + (RemindUnit == 0 ? Tr("u_min") : RemindUnit == 1 ? Tr("u_h") : Tr("u_d"));
            }
        }

        // used for everything clickable (week cards, list rows, sidebar items)
        class Hit
        {
            public Rectangle R, Check;
            public TaskItem Tk;
            public string Key, Text;
            public Color Col;
            public bool Header, Danger;
        }

        class DarkColors : ProfessionalColorTable
        {
            public override Color ToolStripDropDownBackground { get { return cCard; } }
            public override Color ImageMarginGradientBegin { get { return cCard; } }
            public override Color ImageMarginGradientMiddle { get { return cCard; } }
            public override Color ImageMarginGradientEnd { get { return cCard; } }
            public override Color MenuItemSelected { get { return cHover; } }
            public override Color MenuItemSelectedGradientBegin { get { return cHover; } }
            public override Color MenuItemSelectedGradientEnd { get { return cHover; } }
            public override Color MenuItemBorder { get { return cHover; } }
            public override Color MenuBorder { get { return cBorder; } }
            public override Color SeparatorDark { get { return cBorder; } }
            public override Color SeparatorLight { get { return cBorder; } }
        }

        class Popup : Form
        {
            public Color Accent;
            protected override bool ShowWithoutActivation { get { return true; } }
            protected override void OnPaint(PaintEventArgs e)
            {
                base.OnPaint(e);
                using (var pen = new Pen(cBorder, 2f)) e.Graphics.DrawRectangle(pen, 1, 1, Width - 3, Height - 3);
                using (var b = new SolidBrush(Accent)) e.Graphics.FillRectangle(b, 0, 0, P(6), Height);
            }
        }

        enum ViewMode { Week, All, Cat }

        // =================================================================== theme + helpers
        static readonly Color cBg = Color.FromArgb(13, 13, 19);
        static readonly Color cSide = Color.FromArgb(20, 20, 28);
        static readonly Color cCol = Color.FromArgb(21, 22, 31);
        static readonly Color cCard = Color.FromArgb(32, 34, 46);
        static readonly Color cHover = Color.FromArgb(43, 46, 64);
        static readonly Color cBorder = Color.FromArgb(42, 45, 62);
        static readonly Color cText = Color.FromArgb(236, 238, 246);
        static readonly Color cSoft = Color.FromArgb(176, 181, 200);
        static readonly Color cMuted = Color.FromArgb(125, 130, 154);
        static readonly Color cAccent = Color.FromArgb(124, 92, 255);
        static readonly Color cAccentHi = Color.FromArgb(146, 118, 255);
        static readonly Color cDanger = Color.FromArgb(255, 96, 112);
        static readonly Color cOk = Color.FromArgb(74, 210, 140);

        [DllImport("user32.dll")] static extern bool SetProcessDPIAware();
        [DllImport("dwmapi.dll")] static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int val, int size);

        static float scale = 1f;
        static readonly Dictionary<string, Font> fonts = new Dictionary<string, Font>();
        static Bitmap logoBmp;
        static Mutex instanceMutex;

        static Form1()
        {
            try { SetProcessDPIAware(); } catch { }
        }

        static int P(int v) { return (int)Math.Round(v * scale); }

        static Font F(float pt, FontStyle st = FontStyle.Regular)
        {
            string k = pt.ToString(CultureInfo.InvariantCulture) + "|" + (int)st;
            Font f;
            if (!fonts.TryGetValue(k, out f)) { f = new Font("Segoe UI", pt, st, GraphicsUnit.Point); fonts[k] = f; }
            return f;
        }

        static GraphicsPath RR(Rectangle r, int rad)
        {
            var p = new GraphicsPath();
            int d = Math.Max(2, rad * 2);
            p.AddArc(r.X, r.Y, d, d, 180, 90);
            p.AddArc(r.Right - d, r.Y, d, d, 270, 90);
            p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
            p.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
            p.CloseFigure();
            return p;
        }

        static void FillRR(Graphics g, Color c, Rectangle r, int rad)
        {
            using (var p = RR(r, rad)) using (var b = new SolidBrush(c)) g.FillPath(b, p);
        }

        static void Dot(Graphics g, Color c, Rectangle r)
        {
            using (var b = new SolidBrush(c)) g.FillEllipse(b, r);
        }

        static void Txt(Graphics g, string s, Font f, Rectangle r, Color c, TextFormatFlags extra = TextFormatFlags.Left)
        {
            TextRenderer.DrawText(g, s ?? "", f, r, c,
                TextFormatFlags.NoPadding | TextFormatFlags.EndEllipsis | TextFormatFlags.VerticalCenter |
                TextFormatFlags.SingleLine | TextFormatFlags.PreserveGraphicsClipping | extra);
        }

        static void Wrap(Graphics g, string s, Font f, Rectangle r, Color c)
        {
            TextRenderer.DrawText(g, s ?? "", f, r, c,
                TextFormatFlags.NoPadding | TextFormatFlags.EndEllipsis | TextFormatFlags.WordBreak |
                TextFormatFlags.Top | TextFormatFlags.Left | TextFormatFlags.PreserveGraphicsClipping);
        }

        static void DB(Control c)
        {
            typeof(Control).GetProperty("DoubleBuffered", BindingFlags.Instance | BindingFlags.NonPublic).SetValue(c, true, null);
        }

        static void DarkBar(Form f)
        {
            f.HandleCreated += (s, e) => { try { int v = 1; DwmSetWindowAttribute(f.Handle, 20, ref v, 4); } catch { } };
        }

        static Label Lbl(string text, float pt, Color c, FontStyle st = FontStyle.Regular)
        {
            return new Label { Text = text, Font = F(pt, st), ForeColor = c, AutoSize = true, BackColor = Color.Transparent };
        }

        static TextBox Input(bool multi)
        {
            return new TextBox { BorderStyle = BorderStyle.FixedSingle, BackColor = cCard, ForeColor = cText, Font = F(10f), Multiline = multi };
        }

        static ComboBox Combo()
        {
            return new ComboBox { FlatStyle = FlatStyle.Flat, BackColor = cCard, ForeColor = cText, Font = F(10f), DropDownStyle = ComboBoxStyle.DropDownList };
        }

        static void Round(Control c, int radius)
        {
            if (c.Width < 2 || c.Height < 2) return;
            using (var path = RR(new Rectangle(0, 0, c.Width, c.Height), P(radius)))
            {
                var old = c.Region;
                c.Region = new Region(path);
                if (old != null) old.Dispose();
            }
        }

        static Button Btn(string text, bool primary, int w, int h)
        {
            var b = new Button
            {
                Text = text,
                Width = P(w),
                Height = P(h),
                FlatStyle = FlatStyle.Flat,
                BackColor = primary ? cAccent : cCard,
                ForeColor = Color.White,
                Font = F(9.5f, primary ? FontStyle.Bold : FontStyle.Regular),
                Cursor = Cursors.Hand,
                UseVisualStyleBackColor = false
            };
            b.FlatAppearance.BorderSize = 0;
            b.FlatAppearance.MouseOverBackColor = primary ? cAccentHi : cHover;
            b.FlatAppearance.MouseDownBackColor = primary ? cAccent : cBorder;
            Round(b, 8);
            b.SizeChanged += (s, e) => Round(b, 8);
            return b;
        }

        // =================================================================== language
        static string lang = "en";
        static CultureInfo cul = new CultureInfo("en-GB");

        static void SetLang(string l)
        {
            lang = l;
            cul = new CultureInfo(l == "de" ? "de-DE" : "en-GB");
        }

        static string Tr(string key)
        {
            string[] v;
            if (!Dict.TryGetValue(key, out v)) return key;
            return lang == "de" ? v[1] : v[0];
        }

        static readonly Dictionary<string, string[]> Dict = new Dictionary<string, string[]>
        {
            {"app_title", new[]{"Week Planner","Wochenplaner"}},
            {"nav_week", new[]{"Week","Woche"}},
            {"nav_all", new[]{"All tasks","Alle Aufgaben"}},
            {"nav_cats", new[]{"CATEGORIES","KATEGORIEN"}},
            {"new_task", new[]{"+  New task","+  Neue Aufgabe"}},
            {"settings", new[]{"Settings","Einstellungen"}},
            {"today", new[]{"Today","Heute"}},
            {"tomorrow", new[]{"Tomorrow","Morgen"}},
            {"this_week", new[]{"This week","Diese Woche"}},
            {"next_week", new[]{"Next week","Nächste Woche"}},
            {"last_week", new[]{"Last week","Letzte Woche"}},
            {"in_weeks", new[]{"In {0} weeks","In {0} Wochen"}},
            {"weeks_ago", new[]{"{0} weeks ago","Vor {0} Wochen"}},
            {"kw", new[]{"Week {0}","KW {0}"}},
            {"cat_school", new[]{"School","Schule"}},
            {"cat_private", new[]{"Private","Privat"}},
            {"cat_work", new[]{"Work","Arbeit"}},
            {"cat_sport", new[]{"Sport","Sport"}},
            {"new_task_title", new[]{"New task","Neue Aufgabe"}},
            {"edit_task", new[]{"Edit task","Aufgabe bearbeiten"}},
            {"f_title", new[]{"What needs to be done?","Was ist zu tun?"}},
            {"f_cat", new[]{"Category","Kategorie"}},
            {"f_subject", new[]{"Which subject?","Welches Fach?"}},
            {"f_due", new[]{"Due until (date and time)","Fällig bis (Datum und Uhrzeit)"}},
            {"f_remind", new[]{"Remind me","Erinnere mich"}},
            {"before", new[]{"before","vorher"}},
            {"f_notes", new[]{"Notes (optional)","Notizen (optional)"}},
            {"u_minutes", new[]{"minutes","Minuten"}},
            {"u_hours", new[]{"hours","Stunden"}},
            {"u_days", new[]{"days","Tage"}},
            {"u_min", new[]{"min","Min."}},
            {"u_h", new[]{"h","Std."}},
            {"u_d", new[]{"d","Tg."}},
            {"remind_short", new[]{"Remind","Erinn."}},
            {"save", new[]{"Save","Speichern"}},
            {"cancel", new[]{"Cancel","Abbrechen"}},
            {"delete", new[]{"Delete","Löschen"}},
            {"edit", new[]{"Edit","Bearbeiten"}},
            {"details", new[]{"Task details","Aufgabendetails"}},
            {"notes", new[]{"Notes","Notizen"}},
            {"no_notes", new[]{"No notes","Keine Notizen"}},
            {"add", new[]{"Add","Hinzufügen"}},
            {"close", new[]{"Close","Schließen"}},
            {"mark_done", new[]{"Mark as done","Als erledigt markieren"}},
            {"mark_open", new[]{"Mark as open","Wieder öffnen"}},
            {"title_required", new[]{"Please enter a title.","Bitte einen Titel eingeben."}},
            {"name_required", new[]{"Please enter a name.","Bitte einen Namen eingeben."}},
            {"confirm_del", new[]{"Delete this task?","Diese Aufgabe löschen?"}},
            {"confirm_cat_del", new[]{"Delete this category and all its tasks?","Diese Kategorie samt allen Aufgaben löschen?"}},
            {"keep_one", new[]{"You need at least one category.","Du brauchst mindestens eine Kategorie."}},
            {"s_lang", new[]{"Language","Sprache"}},
            {"s_auto", new[]{"Start with Windows (hidden in the tray)","Mit Windows starten (versteckt im Tray)"}},
            {"s_cats", new[]{"Categories","Kategorien"}},
            {"cat_title", new[]{"Category","Kategorie"}},
            {"name", new[]{"Name","Name"}},
            {"color", new[]{"Color","Farbe"}},
            {"ask_subject", new[]{"Ask for a subject when adding a task","Beim Anlegen nach dem Fach fragen"}},
            {"subjects_hint", new[]{"Subjects, separated by commas","Fächer, durch Komma getrennt"}},
            {"reminder", new[]{"Reminder","Erinnerung"}},
            {"due_at", new[]{"Due {0}","Fällig {0}"}},
            {"snooze", new[]{"Snooze 10 min","10 Min. später"}},
            {"done", new[]{"Done","Erledigt"}},
            {"dismiss", new[]{"Dismiss","Schließen"}},
            {"open", new[]{"Open Week Planner","Wochenplaner öffnen"}},
            {"exit", new[]{"Exit","Beenden"}},
            {"tray_hint", new[]{"Still running in the tray so reminders keep working. Use the tray menu to exit.","Läuft im Tray weiter, damit Erinnerungen funktionieren. Beenden über das Tray-Menü."}},
            {"next", new[]{"Next: ","Als Nächstes: "}},
            {"empty_day", new[]{"Nothing planned","Nichts geplant"}},
            {"empty_list", new[]{"No tasks here yet. Add one with  + New task.","Noch keine Aufgaben. Leg eine mit  + Neue Aufgabe an."}},
            {"show_done", new[]{"Show completed tasks","Erledigte anzeigen"}},
            {"n_open", new[]{"{0} open","{0} offen"}},
            {"n_done", new[]{"{0} completed","{0} erledigt"}},
            {"overdue_h", new[]{"Overdue","Überfällig"}},
            {"completed_h", new[]{"Completed","Erledigt"}},
            {"rel_past", new[]{"{0} ago","vor {0}"}},
            {"rel_future", new[]{"in {0}","in {0}"}},
        };

        // =================================================================== data + saving
        static readonly List<Category> cats = new List<Category>();
        static readonly List<TaskItem> tasks = new List<TaskItem>();
        static bool trayHint;

        static string DataDir { get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "WeekPlanner"); } }
        static string DataFile { get { return Path.Combine(DataDir, "data.txt"); } }

        static string Esc(string s)
        {
            return (s ?? "").Replace("\\", "\\\\").Replace("\t", "\\t").Replace("\r", "\\r").Replace("\n", "\\n");
        }

        static string Unesc(string s)
        {
            var sb = new StringBuilder();
            for (int i = 0; i < s.Length; i++)
            {
                char c = s[i];
                if (c == '\\' && i + 1 < s.Length)
                {
                    char n = s[++i];
                    sb.Append(n == 't' ? '\t' : n == 'r' ? '\r' : n == 'n' ? '\n' : n);
                }
                else sb.Append(c);
            }
            return sb.ToString();
        }

        static void SaveData()
        {
            try
            {
                Directory.CreateDirectory(DataDir);
                var inv = CultureInfo.InvariantCulture;
                var sb = new StringBuilder();
                sb.AppendLine("LANG\t" + lang);
                sb.AppendLine("HINT\t" + (trayHint ? "1" : "0"));
                foreach (var c in cats)
                    sb.AppendLine(string.Join("\t", new[]
                    {
                        "CAT", Esc(c.Id), Esc(c.CustomName), c.Rgb.ToString(inv), c.AsksSubject ? "1" : "0",
                        string.Join("\u001f", c.Subjects.Select(x => Esc(x)).ToArray())
                    }));
                foreach (var t in tasks)
                    sb.AppendLine(string.Join("\t", new[]
                    {
                        "TASK", Esc(t.Id), Esc(t.Title), Esc(t.CategoryId), Esc(t.Subject), Esc(t.Notes),
                        t.Due.Ticks.ToString(inv), t.Done ? "1" : "0", t.RemindEnabled ? "1" : "0",
                        t.RemindAmount.ToString(inv), t.RemindUnit.ToString(inv), t.Reminded ? "1" : "0",
                        t.SnoozeUntil == DateTime.MinValue ? "0" : t.SnoozeUntil.Ticks.ToString(inv)
                    }));
                string tmp = DataFile + ".tmp";
                File.WriteAllText(tmp, sb.ToString(), Encoding.UTF8);
                File.Copy(tmp, DataFile, true);
                File.Delete(tmp);
            }
            catch { }
        }

        static void LoadData()
        {
            cats.Clear(); tasks.Clear();
            string l = null;
            var inv = CultureInfo.InvariantCulture;
            try
            {
                if (File.Exists(DataFile))
                {
                    foreach (var line in File.ReadAllLines(DataFile, Encoding.UTF8))
                    {
                        var p = line.Split('\t');
                        if (p[0] == "LANG" && p.Length > 1) l = p[1];
                        else if (p[0] == "HINT" && p.Length > 1) trayHint = p[1] == "1";
                        else if (p[0] == "CAT" && p.Length >= 6)
                        {
                            var c = new Category { Id = Unesc(p[1]), Rgb = int.Parse(p[3], inv), AsksSubject = p[4] == "1" };
                            string cn = Unesc(p[2]);
                            c.CustomName = cn == "" ? null : cn;
                            if (p[5] != "") c.Subjects = p[5].Split('\u001f').Select(x => Unesc(x)).ToList();
                            cats.Add(c);
                        }
                        else if (p[0] == "TASK" && p.Length >= 13)
                        {
                            long sn = long.Parse(p[12], inv);
                            tasks.Add(new TaskItem
                            {
                                Id = Unesc(p[1]),
                                Title = Unesc(p[2]),
                                CategoryId = Unesc(p[3]),
                                Subject = Unesc(p[4]),
                                Notes = Unesc(p[5]),
                                Due = new DateTime(long.Parse(p[6], inv)),
                                Done = p[7] == "1",
                                RemindEnabled = p[8] == "1",
                                RemindAmount = int.Parse(p[9], inv),
                                RemindUnit = int.Parse(p[10], inv),
                                Reminded = p[11] == "1",
                                SnoozeUntil = sn == 0 ? DateTime.MinValue : new DateTime(sn)
                            });
                        }
                    }
                }
            }
            catch
            {
                try { File.Copy(DataFile, DataFile + ".bak", true); } catch { }
                cats.Clear(); tasks.Clear();
            }

            if (string.IsNullOrEmpty(l)) l = CultureInfo.CurrentUICulture.TwoLetterISOLanguageName == "de" ? "de" : "en";
            SetLang(l);
            if (cats.Count == 0) SeedCategories();
        }

        static void SeedCategories()
        {
            bool de = lang == "de";
            cats.Add(new Category
            {
                Id = "school",
                Rgb = Color.FromArgb(124, 92, 255).ToArgb(),
                AsksSubject = true,
                Subjects = de
                    ? new List<string> { "Mathe", "Deutsch", "Englisch", "Physik", "Chemie", "Biologie", "Geschichte", "Informatik", "Sport" }
                    : new List<string> { "Math", "English", "German", "Physics", "Chemistry", "Biology", "History", "Computer Science", "PE" }
            });
            cats.Add(new Category { Id = "private", Rgb = Color.FromArgb(56, 189, 248).ToArgb() });
            cats.Add(new Category { Id = "work", Rgb = Color.FromArgb(251, 191, 36).ToArgb() });
            cats.Add(new Category { Id = "sport", Rgb = Color.FromArgb(74, 222, 128).ToArgb() });
        }

        static Category Cat(string id)
        {
            return cats.FirstOrDefault(c => c.Id == id) ?? cats.FirstOrDefault();
        }

        // =================================================================== misc helpers
        static DateTime WeekStartOf(DateTime d)
        {
            int diff = ((int)d.DayOfWeek + 6) % 7;
            return d.Date.AddDays(-diff);
        }

        static string Rel(DateTime due)
        {
            var d = due - DateTime.Now;
            bool past = d < TimeSpan.Zero;
            d = d.Duration();
            string s;
            if (d.TotalDays >= 1) s = (int)d.TotalDays + " " + Tr("u_d") + " " + d.Hours + " " + Tr("u_h");
            else if (d.TotalHours >= 1) s = (int)d.TotalHours + " " + Tr("u_h") + " " + d.Minutes + " " + Tr("u_min");
            else s = Math.Max(1, (int)d.TotalMinutes) + " " + Tr("u_min");
            return string.Format(Tr(past ? "rel_past" : "rel_future"), s);
        }

        static string DayTitle(DateTime d)
        {
            string s = d.ToString("dddd d MMMM", cul);
            if (d.Date == DateTime.Today) return Tr("today") + "  ·  " + s;
            if (d.Date == DateTime.Today.AddDays(1)) return Tr("tomorrow") + "  ·  " + s;
            return s;
        }

        static string Cut(string s, int n)
        {
            return s.Length <= n ? s : s.Substring(0, n - 1) + "…";
        }

        static bool AutoStartEnabled()
        {
            try { using (var k = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Run")) return k != null && k.GetValue("WeekPlanner") != null; }
            catch { return false; }
        }

        static void SetAutoStart(bool on)
        {
            try
            {
                using (var k = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Run", true))
                {
                    if (k == null) return;
                    if (on) k.SetValue("WeekPlanner", "\"" + Application.ExecutablePath + "\" --tray");
                    else k.DeleteValue("WeekPlanner", false);
                }
            }
            catch { }
        }

        static Icon MakeIcon()
        {
            logoBmp = new Bitmap(64, 64);
            using (var g = Graphics.FromImage(logoBmp))
            {
                g.SmoothingMode = SmoothingMode.AntiAlias;
                g.Clear(Color.Transparent);
                using (var path = RR(new Rectangle(2, 2, 60, 60), 14))
                using (var b = new LinearGradientBrush(new Rectangle(0, 0, 64, 64), Color.FromArgb(146, 118, 255), Color.FromArgb(98, 70, 235), 60f))
                    g.FillPath(b, path);
                FillRR(g, Color.White, new Rectangle(14, 16, 36, 9), 4);
                for (int r = 0; r < 2; r++)
                    for (int c = 0; c < 3; c++)
                        FillRR(g, Color.FromArgb(r == 1 && c == 2 ? 255 : 190, 255, 255, 255), new Rectangle(14 + c * 14, 31 + r * 13, 8, 8), 3);
            }
            return Icon.FromHandle(logoBmp.GetHicon());
        }

        // =================================================================== UI state
        Panel sideP, contentP, topP, weekP, listP;
        Label lblTitle, lblSub;
        Button btnPrev, btnToday, btnNext, btnNew;
        CheckBox chkDone;
        NotifyIcon tray;
        System.Windows.Forms.Timer timer;
        Icon appIcon;
        ViewMode mode = ViewMode.Week;
        string catId;
        int weekOffset;
        bool exiting, startHidden;
        int lastMinute = -1;

        readonly List<Hit> navHits = new List<Hit>();
        int navHover = -1;

        readonly List<Hit> wHits = new List<Hit>();
        readonly List<Rectangle> plusRects = new List<Rectangle>();
        readonly List<Rectangle> colRects = new List<Rectangle>();
        int wScroll, wTop0, wViewH, wMax, plusHover = -1;
        TaskItem wHover;

        readonly List<Hit> lRows = new List<Hit>();
        int lScroll, lMax;
        TaskItem lHover;

        // =================================================================== constructor + layout
        public Form1()
        {
            InitializeComponent();
            if (System.ComponentModel.LicenseManager.UsageMode == System.ComponentModel.LicenseUsageMode.Designtime) return;

            bool created;
            instanceMutex = new Mutex(true, "Local\\WeekPlanner_SingleInstance", out created);
            if (!created)
            {
                MessageBox.Show("Week Planner is already running. Look for it in the system tray.", "Week Planner");
                Environment.Exit(0);
            }
            startHidden = Environment.GetCommandLineArgs().Skip(1).Contains("--tray");

            using (var g = Graphics.FromHwnd(IntPtr.Zero)) scale = g.DpiX / 96f;
            LoadData();

            Text = "Week Planner";
            BackColor = cBg; ForeColor = cText; Font = F(9.5f);
            StartPosition = FormStartPosition.CenterScreen;
            var wa = Screen.PrimaryScreen.WorkingArea;
            ClientSize = new Size(Math.Min(P(1400), wa.Width - P(40)), Math.Min(P(860), wa.Height - P(100)));
            MinimumSize = new Size(Math.Min(P(1100), wa.Width), Math.Min(P(640), wa.Height));
            KeyPreview = true;
            appIcon = MakeIcon();
            Icon = appIcon;
            DarkBar(this);

            BuildLayout();
            BuildTray();
            RefreshAll();

            timer = new System.Windows.Forms.Timer { Interval = 1500 };
            timer.Tick += (s, e) => { timer.Interval = 15000; OnTick(); };
            timer.Start();
        }

        void BuildLayout()
        {
            contentP = new Panel { Dock = DockStyle.Fill, BackColor = cBg };
            topP = new Panel { Dock = DockStyle.Top, Height = P(84), BackColor = cBg };
            weekP = new Panel { Dock = DockStyle.Fill, BackColor = cBg };
            listP = new Panel { Dock = DockStyle.Fill, BackColor = cBg, Visible = false };
            sideP = new Panel { Dock = DockStyle.Left, Width = P(232), BackColor = cSide };
            DB(weekP); DB(listP); DB(sideP);

            // top bar
            lblTitle = Lbl("", 20f, cText, FontStyle.Bold); lblTitle.Location = new Point(P(26), P(8));
            lblSub = Lbl("", 10f, cMuted); lblSub.Location = new Point(P(29), P(50));
            btnPrev = Btn("‹", false, 44, 38);
            btnNext = Btn("›", false, 44, 38);
            btnToday = Btn("", false, 96, 38);
            btnPrev.Font = F(13f); btnNext.Font = F(13f);
            btnPrev.Click += (s, e) => { weekOffset--; wScroll = 0; RefreshAll(); };
            btnNext.Click += (s, e) => { weekOffset++; wScroll = 0; RefreshAll(); };
            btnToday.Click += (s, e) => { weekOffset = 0; wScroll = 0; RefreshAll(); };
            chkDone = new CheckBox { AutoSize = false, Width = P(210), Height = P(26), ForeColor = cSoft, BackColor = cBg, Font = F(9.5f), Visible = false };
            chkDone.CheckedChanged += (s, e) => RefreshAll();
            topP.Controls.AddRange(new Control[] { lblTitle, lblSub, btnPrev, btnToday, btnNext, chkDone });
            topP.Resize += (s, e) => LayoutTop();
            LayoutTop();

            // sidebar
            btnNew = Btn("", true, 196, 42);
            btnNew.Location = new Point(P(18), P(82));
            btnNew.Click += (s, e) => NewTask(null);
            sideP.Controls.Add(btnNew);
            sideP.Paint += SidePaint;
            sideP.MouseMove += SideMove;
            sideP.MouseLeave += (s, e) => { if (navHover != -1) { navHover = -1; sideP.Invalidate(); } };
            sideP.MouseClick += SideClick;
            sideP.Resize += (s, e) => sideP.Invalidate();

            // week + list
            weekP.Paint += WeekPaint;
            weekP.MouseMove += WeekMove;
            weekP.MouseLeave += (s, e) => { wHover = null; plusHover = -1; weekP.Invalidate(); };
            weekP.MouseClick += WeekClick;
            weekP.MouseDoubleClick += WeekDouble;
            weekP.Resize += (s, e) => weekP.Invalidate();
            listP.Paint += ListPaint;
            listP.MouseMove += ListMove;
            listP.MouseLeave += (s, e) => { lHover = null; listP.Invalidate(); };
            listP.MouseClick += ListClick;
            listP.Resize += (s, e) => listP.Invalidate();

            contentP.Controls.Add(weekP);
            contentP.Controls.Add(listP);
            contentP.Controls.Add(topP);
            Controls.Add(contentP);
            Controls.Add(sideP);
        }

        void LayoutTop()
        {
            int y = P(22);
            btnNext.Location = new Point(topP.Width - P(26) - btnNext.Width, y);
            btnToday.Location = new Point(btnNext.Left - P(8) - btnToday.Width, y);
            btnPrev.Location = new Point(btnToday.Left - P(8) - btnPrev.Width, y);
            chkDone.Location = new Point(topP.Width - P(26) - chkDone.Width, P(28));
        }

        // =================================================================== state helpers
        DateTime CurrentWeekStart() { return WeekStartOf(DateTime.Today).AddDays(7 * weekOffset); }
        string CurrentKey() { return mode == ViewMode.Week ? "week" : mode == ViewMode.All ? "all" : catId; }

        int OpenCountFor(string key)
        {
            var open = tasks.Where(t => !t.Done);
            if (key == "week") { var ws = CurrentWeekStart(); return open.Count(t => t.Due.Date >= ws && t.Due.Date < ws.AddDays(7)); }
            if (key == "all") return open.Count();
            if (key == "settings") return 0;
            return open.Count(t => t.CategoryId == key);
        }

        IEnumerable<TaskItem> ListSource()
        {
            string cid = mode == ViewMode.Cat ? catId : null;
            return tasks.Where(t => cid == null || t.CategoryId == cid);
        }

        void SelectView(string key)
        {
            if (key == "week") { mode = ViewMode.Week; catId = null; }
            else if (key == "all") { mode = ViewMode.All; catId = null; }
            else { mode = ViewMode.Cat; catId = key; }
            lScroll = 0;
            RefreshAll();
        }

        void RefreshAll()
        {
            if (mode == ViewMode.Cat && !cats.Any(c => c.Id == catId)) { mode = ViewMode.Week; catId = null; }
            bool isWeek = mode == ViewMode.Week;
            var ws = CurrentWeekStart();

            weekP.Visible = isWeek;
            listP.Visible = !isWeek;
            btnPrev.Visible = btnNext.Visible = btnToday.Visible = isWeek;
            chkDone.Visible = !isWeek;
            btnToday.Text = Tr("today");
            chkDone.Text = Tr("show_done");
            btnNew.Text = Tr("new_task");

            if (isWeek)
            {
                lblTitle.Text = weekOffset == 0 ? Tr("this_week")
                              : weekOffset == 1 ? Tr("next_week")
                              : weekOffset == -1 ? Tr("last_week")
                              : weekOffset > 1 ? string.Format(Tr("in_weeks"), weekOffset)
                              : string.Format(Tr("weeks_ago"), -weekOffset);
                int kw = CultureInfo.InvariantCulture.Calendar.GetWeekOfYear(ws.AddDays(3), CalendarWeekRule.FirstFourDayWeek, DayOfWeek.Monday);
                lblSub.Text = ws.ToString("ddd d MMM", cul) + "  –  " + ws.AddDays(6).ToString("ddd d MMM yyyy", cul)
                              + "   ·   " + string.Format(Tr("kw"), kw);
            }
            else
            {
                lblTitle.Text = mode == ViewMode.All ? Tr("nav_all") : Cat(catId).Name;
                var src = ListSource().ToList();
                lblSub.Text = string.Format(Tr("n_open"), src.Count(t => !t.Done)) + "   ·   " + string.Format(Tr("n_done"), src.Count(t => t.Done));
            }

            sideP.Invalidate();
            weekP.Invalidate();
            listP.Invalidate();
        }

        void Changed()
        {
            SaveData();
            RefreshAll();
        }

        // =================================================================== sidebar
        void AddNavHit(string key, string text, Color col, ref int y)
        {
            navHits.Add(new Hit { R = new Rectangle(P(12), y, P(208), P(40)), Key = key, Text = text, Col = col });
            y += P(44);
        }

        void SidePaint(object sender, PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.Clear(cSide);
            g.DrawImage(logoBmp, new Rectangle(P(20), P(22), P(34), P(34)));
            Txt(g, Tr("app_title"), F(14f, FontStyle.Bold), new Rectangle(P(62), P(22), P(160), P(34)), cText);

            navHits.Clear();
            int y = P(144);
            AddNavHit("week", Tr("nav_week"), cAccent, ref y);
            AddNavHit("all", Tr("nav_all"), cMuted, ref y);
            y += P(14);
            Txt(g, Tr("nav_cats"), F(8f, FontStyle.Bold), new Rectangle(P(22), y, P(180), P(18)), cMuted);
            y += P(26);
            foreach (var c in cats) AddNavHit(c.Id, c.Name, c.Col, ref y);
            navHits.Add(new Hit { R = new Rectangle(P(12), sideP.Height - P(54), P(208), P(40)), Key = "settings", Text = Tr("settings"), Col = cBorder });

            string cur = CurrentKey();
            for (int i = 0; i < navHits.Count; i++)
            {
                var h = navHits[i];
                var rr = new Rectangle(h.R.X, h.R.Y, h.R.Width - 1, h.R.Height - 1);
                bool sel = h.Key == cur;
                if (sel) FillRR(g, cCard, rr, P(10));
                else if (i == navHover) FillRR(g, Color.FromArgb(24, 255, 255, 255), rr, P(10));
                Dot(g, h.Col, new Rectangle(h.R.X + P(16), h.R.Y + (h.R.Height - P(10)) / 2, P(10), P(10)));
                Txt(g, h.Text, F(10f), new Rectangle(h.R.X + P(38), h.R.Y, h.R.Width - P(38) - P(44), h.R.Height), sel ? cText : cSoft);
                int n = OpenCountFor(h.Key);
                if (n > 0) Txt(g, n.ToString(), F(8.5f, FontStyle.Bold), new Rectangle(h.R.Right - P(46), h.R.Y, P(32), h.R.Height), cMuted, TextFormatFlags.Right);
            }
            using (var pen = new Pen(cBorder)) g.DrawLine(pen, sideP.Width - 1, 0, sideP.Width - 1, sideP.Height);
        }

        int NavAt(Point p)
        {
            for (int i = 0; i < navHits.Count; i++) if (navHits[i].R.Contains(p)) return i;
            return -1;
        }

        void SideMove(object sender, MouseEventArgs e)
        {
            int i = NavAt(e.Location);
            if (i != navHover) { navHover = i; sideP.Cursor = i >= 0 ? Cursors.Hand : Cursors.Default; sideP.Invalidate(); }
        }

        void SideClick(object sender, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left) return;
            int i = NavAt(e.Location);
            if (i < 0) return;
            if (navHits[i].Key == "settings") OpenSettings(); else SelectView(navHits[i].Key);
        }

        // =================================================================== drawing of cards
        static Rectangle CheckRect(Rectangle card)
        {
            return new Rectangle(card.Right - P(32), card.Bottom - P(34), P(20), P(20));
        }

        static Rectangle ListCheckRect(Rectangle row)
        {
            return new Rectangle(row.X + P(18), row.Y + (row.Height - P(22)) / 2, P(22), P(22));
        }

        static void DrawCheck(Graphics g, Rectangle c, bool done)
        {
            if (done)
            {
                Dot(g, cOk, c);
                using (var pen = new Pen(Color.White, 2f) { StartCap = LineCap.Round, EndCap = LineCap.Round, LineJoin = LineJoin.Round })
                {
                    float k = c.Width / 20f;
                    g.DrawLines(pen, new[]
                    {
                        new PointF(c.X + 5.5f * k, c.Y + 10.5f * k),
                        new PointF(c.X + 8.8f * k, c.Y + 13.8f * k),
                        new PointF(c.X + 14.5f * k, c.Y + 6.5f * k)
                    });
                }
            }
            else
            {
                using (var pen = new Pen(cMuted, 1.6f)) g.DrawEllipse(pen, c.X + 1, c.Y + 1, c.Width - 2, c.Height - 2);
            }
        }

        static void DrawWeekCard(Graphics g, Rectangle r, TaskItem t, bool hover)
        {
            var cat = Cat(t.CategoryId);
            var col = cat.Col;
            FillRR(g, hover ? cHover : cCard, r, P(10));
            FillRR(g, t.Done ? Color.FromArgb(80, col) : col, new Rectangle(r.X + P(8), r.Y + P(10), P(4), r.Height - P(20)), P(2));

            int tx = r.X + P(20), w = r.Width - P(20) - P(8);
            bool over = !t.Done && t.Due < DateTime.Now;

            Wrap(g, t.Title, t.Done ? F(9.5f, FontStyle.Strikeout) : F(9.5f, FontStyle.Bold),
                new Rectangle(tx, r.Y + P(8), w, P(36)), t.Done ? cMuted : cText);

            string l2 = t.Due.ToString("HH:mm") + (string.IsNullOrWhiteSpace(t.Subject) ? "" : "  ·  " + t.Subject);
            Txt(g, l2, F(8.5f), new Rectangle(tx, r.Y + P(46), w - P(26), P(16)), over ? cDanger : cSoft);

            string l3 = cat.Name + (t.RemindEnabled ? "  ·  " + Tr("remind_short") + " " + t.ReminderShort() : "");
            Txt(g, l3, F(8f), new Rectangle(tx, r.Y + P(64), w - P(26), P(16)), cMuted);

            DrawCheck(g, CheckRect(r), t.Done);
        }

        static void DrawListRow(Graphics g, Rectangle r, TaskItem t, bool hover)
        {
            var cat = Cat(t.CategoryId);
            var col = cat.Col;
            FillRR(g, hover ? cHover : cCard, r, P(10));
            FillRR(g, t.Done ? Color.FromArgb(80, col) : col, new Rectangle(r.X + P(6), r.Y + P(12), P(4), r.Height - P(24)), P(2));
            DrawCheck(g, ListCheckRect(r), t.Done);

            int tx = r.X + P(56);
            int leftW = r.Width - P(56) - P(220);
            bool over = !t.Done && t.Due < DateTime.Now;

            Txt(g, t.Title, t.Done ? F(10.5f, FontStyle.Strikeout) : F(10.5f, FontStyle.Bold),
                new Rectangle(tx, r.Y + P(10), leftW, P(22)), t.Done ? cMuted : cText);

            string sub = cat.Name;
            if (!string.IsNullOrWhiteSpace(t.Subject)) sub += "  ·  " + t.Subject;
            if (t.RemindEnabled) sub += "  ·  " + Tr("remind_short") + " " + t.ReminderShort();
            Txt(g, sub, F(9f), new Rectangle(tx, r.Y + P(34), leftW, P(20)), cMuted);

            string when = t.Due.ToString("ddd d MMM", cul) + "  ·  " + t.Due.ToString("HH:mm");
            Txt(g, when, F(10f), new Rectangle(r.Right - P(210), r.Y + P(10), P(194), P(22)), t.Done ? cMuted : cText, TextFormatFlags.Right);
            if (!t.Done)
                Txt(g, Rel(t.Due), F(9f), new Rectangle(r.Right - P(210), r.Y + P(34), P(194), P(20)), over ? cDanger : cSoft, TextFormatFlags.Right);
        }

        // =================================================================== week view
        Rectangle ColRect(int i)
        {
            int pad = P(16), gap = P(10);
            int w = (weekP.Width - 2 * pad - 6 * gap) / 7;
            return new Rectangle(pad + i * (w + gap), pad, w, weekP.Height - 2 * pad);
        }

        void WeekPaint(object sender, PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.Clear(cBg);
            wHits.Clear(); plusRects.Clear(); colRects.Clear();

            int pad = P(16), hdr = P(70), cardH = P(88), gap = P(8);
            wTop0 = pad + hdr + P(4);
            var ws = CurrentWeekStart();

            var lists = new List<List<TaskItem>>();
            int maxCount = 0;
            for (int i = 0; i < 7; i++)
            {
                var d = ws.AddDays(i).Date;
                var l = tasks.Where(t => t.Due.Date == d).OrderBy(t => t.Done).ThenBy(t => t.Due).ToList();
                lists.Add(l);
                maxCount = Math.Max(maxCount, l.Count);
            }

            int contentH = maxCount * (cardH + gap);
            wViewH = Math.Max(1, weekP.Height - wTop0 - pad);
            wMax = Math.Max(0, contentH - wViewH);
            wScroll = Math.Max(0, Math.Min(wScroll, wMax));

            for (int i = 0; i < 7; i++)
            {
                var cr = ColRect(i);
                colRects.Add(cr);
                var d = ws.AddDays(i).Date;
                bool today = d == DateTime.Today;

                FillRR(g, cCol, cr, P(14));
                using (var pen = new Pen(today ? cAccent : cBorder, today ? 1.6f : 1f))
                using (var path = RR(new Rectangle(cr.X, cr.Y, cr.Width - 1, cr.Height - 1), P(14)))
                    g.DrawPath(pen, path);

                var state = g.Save();
                g.SetClip(new Rectangle(cr.X + 1, wTop0, cr.Width - 2, Math.Max(1, cr.Bottom - wTop0 - P(3))));
                var list = lists[i];
                if (list.Count == 0)
                    Txt(g, Tr("empty_day"), F(9f), new Rectangle(cr.X + P(10), wTop0 + P(4), cr.Width - P(20), P(30)),
                        Color.FromArgb(88, 92, 112), TextFormatFlags.HorizontalCenter);
                for (int k = 0; k < list.Count; k++)
                {
                    int y = wTop0 - wScroll + k * (cardH + gap);
                    if (y + cardH < wTop0 || y > weekP.Height) continue;
                    var r = new Rectangle(cr.X + P(8), y, cr.Width - P(16), cardH);
                    wHits.Add(new Hit { R = r, Check = CheckRect(r), Tk = list[k] });
                    DrawWeekCard(g, r, list[k], list[k] == wHover);
                }
                g.Restore(state);

                // header (stays in place while the cards scroll)
                string dayName = d.ToString("ddd", cul).ToUpper(cul).TrimEnd('.');
                Txt(g, dayName, F(8.5f, FontStyle.Bold), new Rectangle(cr.X + P(14), cr.Y + P(12), cr.Width - P(50), P(16)), today ? cAccent : cMuted);
                string num = d.Day.ToString();
                var numFont = F(20f, FontStyle.Bold);
                Txt(g, num, numFont, new Rectangle(cr.X + P(14), cr.Y + P(28), P(44), P(34)), today ? cAccent : cText);
                int nw = TextRenderer.MeasureText(num, numFont, new Size(P(200), P(40)), TextFormatFlags.NoPadding).Width;
                Txt(g, d.ToString("MMM", cul).TrimEnd('.'), F(9f), new Rectangle(cr.X + P(14) + nw + P(4), cr.Y + P(38), P(50), P(20)), cMuted);

                var plus = new Rectangle(cr.Right - P(34), cr.Y + P(12), P(22), P(22));
                plusRects.Add(plus);
                Dot(g, plusHover == i ? cAccent : cCard, plus);
                using (var pen = new Pen(plusHover == i ? Color.White : cSoft, 1.6f))
                {
                    int cx = plus.X + plus.Width / 2, cy = plus.Y + plus.Height / 2, a = P(5);
                    g.DrawLine(pen, cx - a, cy, cx + a, cy);
                    g.DrawLine(pen, cx, cy - a, cx, cy + a);
                }
            }

            if (wMax > 0)
            {
                int thumbH = Math.Max(P(30), wViewH * wViewH / (wViewH + wMax));
                int thumbY = wTop0 + (wViewH - thumbH) * wScroll / wMax;
                FillRR(g, Color.FromArgb(70, 76, 100), new Rectangle(weekP.Width - P(8), thumbY, P(4), thumbH), P(2));
            }
        }

        Hit WeekHitAt(Point p)
        {
            if (p.Y < wTop0) return null;
            for (int i = wHits.Count - 1; i >= 0; i--) if (wHits[i].R.Contains(p)) return wHits[i];
            return null;
        }

        int PlusAt(Point p)
        {
            for (int i = 0; i < plusRects.Count; i++)
            {
                var r = plusRects[i];
                r.Inflate(P(4), P(4));
                if (r.Contains(p)) return i;
            }
            return -1;
        }

        void WeekMove(object sender, MouseEventArgs e)
        {
            var h = WeekHitAt(e.Location);
            int ph = PlusAt(e.Location);
            var t = h == null ? null : h.Tk;
            if (t != wHover || ph != plusHover)
            {
                wHover = t; plusHover = ph;
                weekP.Cursor = (t != null || ph >= 0) ? Cursors.Hand : Cursors.Default;
                weekP.Invalidate();
            }
        }

        void WeekClick(object sender, MouseEventArgs e)
        {
            int ph = PlusAt(e.Location);
            var h = WeekHitAt(e.Location);
            if (e.Button == MouseButtons.Right)
            {
                if (h != null) ShowContext(h.Tk, weekP.PointToScreen(e.Location));
                return;
            }
            if (e.Button != MouseButtons.Left) return;
            if (ph >= 0) { NewTask(CurrentWeekStart().AddDays(ph)); return; }
            if (h == null) return;
            var chk = h.Check;
            chk.Inflate(P(6), P(6));
            if (chk.Contains(e.Location)) Toggle(h.Tk); else ShowDetails(h.Tk);
        }

        void WeekDouble(object sender, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left || WeekHitAt(e.Location) != null || PlusAt(e.Location) >= 0) return;
            for (int i = 0; i < colRects.Count; i++)
                if (colRects[i].Contains(e.Location) && e.Y >= wTop0) { NewTask(CurrentWeekStart().AddDays(i)); return; }
        }

        // =================================================================== list view
        void ListPaint(object sender, PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.Clear(cBg);

            // build rows
            lRows.Clear();
            var src = ListSource().ToList();
            var open = src.Where(t => !t.Done).OrderBy(t => t.Due).ToList();
            var over = open.Where(t => t.Due.Date < DateTime.Today).ToList();
            if (over.Count > 0)
            {
                lRows.Add(new Hit { Header = true, Danger = true, Text = Tr("overdue_h") });
                foreach (var t in over) lRows.Add(new Hit { Tk = t });
            }
            foreach (var grp in open.Where(t => t.Due.Date >= DateTime.Today).GroupBy(t => t.Due.Date))
            {
                lRows.Add(new Hit { Header = true, Text = DayTitle(grp.Key) });
                foreach (var t in grp) lRows.Add(new Hit { Tk = t });
            }
            if (chkDone.Checked)
            {
                var done = src.Where(t => t.Done).OrderByDescending(t => t.Due).ToList();
                if (done.Count > 0)
                {
                    lRows.Add(new Hit { Header = true, Text = Tr("completed_h") });
                    foreach (var t in done) lRows.Add(new Hit { Tk = t });
                }
            }

            int pad = P(24), headerH = P(40), rowH = P(66), gap = P(8), H = listP.Height;
            int total = P(8);
            foreach (var r in lRows) total += r.Header ? headerH : rowH + gap;
            lMax = Math.Max(0, total - H + P(16));
            lScroll = Math.Max(0, Math.Min(lScroll, lMax));

            if (lRows.Count == 0)
            {
                Txt(g, Tr("empty_list"), F(10.5f), new Rectangle(0, H / 2 - P(20), listP.Width, P(40)), cMuted, TextFormatFlags.HorizontalCenter);
                return;
            }

            int y = P(8) - lScroll;
            foreach (var r in lRows)
            {
                int h = r.Header ? headerH : rowH;
                r.R = new Rectangle(pad, y, listP.Width - 2 * pad - P(6), h);
                if (y + h > 0 && y < H)
                {
                    if (r.Header) Txt(g, r.Text, F(9.5f, FontStyle.Bold), new Rectangle(pad + P(4), y + P(8), r.R.Width, P(26)), r.Danger ? cDanger : cMuted);
                    else DrawListRow(g, r.R, r.Tk, r.Tk == lHover);
                }
                y += r.Header ? headerH : rowH + gap;
            }

            if (lMax > 0)
            {
                int thumbH = Math.Max(P(30), H * H / (H + lMax));
                int thumbY = (H - thumbH) * lScroll / lMax;
                FillRR(g, Color.FromArgb(70, 76, 100), new Rectangle(listP.Width - P(10), thumbY, P(4), thumbH), P(2));
            }
        }

        Hit ListRowAt(Point p)
        {
            foreach (var r in lRows) if (!r.Header && r.R.Contains(p)) return r;
            return null;
        }

        void ListMove(object sender, MouseEventArgs e)
        {
            var r = ListRowAt(e.Location);
            var t = r == null ? null : r.Tk;
            if (t != lHover) { lHover = t; listP.Cursor = t != null ? Cursors.Hand : Cursors.Default; listP.Invalidate(); }
        }

        void ListClick(object sender, MouseEventArgs e)
        {
            var r = ListRowAt(e.Location);
            if (r == null) return;
            if (e.Button == MouseButtons.Right) { ShowContext(r.Tk, listP.PointToScreen(e.Location)); return; }
            if (e.Button != MouseButtons.Left) return;
            var chk = ListCheckRect(r.R);
            chk.Inflate(P(8), P(8));
            if (chk.Contains(e.Location)) Toggle(r.Tk); else ShowDetails(r.Tk);
        }

        // =================================================================== task actions
        DateTime DefaultDue(DateTime? day)
        {
            var d = (day ?? DateTime.Today).Date;
            if (d == DateTime.Today)
            {
                var n = DateTime.Now.AddHours(1);
                return new DateTime(n.Year, n.Month, n.Day, n.Hour, 0, 0);
            }
            return d.AddHours(8);
        }

        void NewTask(DateTime? day)
        {
            var t = new TaskItem
            {
                CategoryId = mode == ViewMode.Cat ? catId : cats[0].Id,
                Due = DefaultDue(day),
                RemindEnabled = true,
                RemindAmount = 1,
                RemindUnit = 1
            };
            bool deleted;
            if (TaskDialog(t, true, out deleted)) { tasks.Add(t); Changed(); }
        }

        void OpenEditor(TaskItem t)
        {
            bool deleted;
            if (!TaskDialog(t, false, out deleted)) return;
            if (deleted) tasks.Remove(t);
            Changed();
        }

        // read-only window showing title, due date and notes of a task
        void ShowDetails(TaskItem t)
        {
            var f = NewDialog(Tr("details"), 440, 420);
            var cat = Cat(t.CategoryId);

            var lblCat = Lbl(cat.Name.ToUpper(cul), 8f, cat.Col, FontStyle.Bold);
            lblCat.Location = new Point(P(20), P(16));

            var title = new Label
            {
                Text = t.Title,
                Font = F(14f, FontStyle.Bold),
                ForeColor = cText,
                BackColor = Color.Transparent,
                AutoSize = false,
                Location = new Point(P(20), P(38)),
                Size = new Size(P(400), P(64))
            };

            string when = t.Due.ToString("dddd d MMMM yyyy, HH:mm", cul);
            if (!string.IsNullOrWhiteSpace(t.Subject)) when += "  ·  " + t.Subject;
            var lblWhen = Lbl(when, 9.5f, cSoft);
            lblWhen.Location = new Point(P(20), P(104));

            var lblNotes = Lbl(Tr("notes"), 9f, cMuted);
            lblNotes.Location = new Point(P(20), P(136));

            bool hasNotes = !string.IsNullOrWhiteSpace(t.Notes);
            var tbNotes = Input(true);
            tbNotes.ReadOnly = true;
            tbNotes.BackColor = cCard;
            tbNotes.ScrollBars = ScrollBars.Vertical;
            tbNotes.Location = new Point(P(20), P(158));
            tbNotes.Size = new Size(P(400), P(180));
            tbNotes.Text = hasNotes ? t.Notes : Tr("no_notes");
            tbNotes.ForeColor = hasNotes ? cText : cMuted;
            tbNotes.TabStop = false;

            bool wantEdit = false;
            var close = Btn(Tr("close"), true, 110, 38);
            close.Location = new Point(P(440) - P(20) - close.Width, P(420) - P(58));
            close.DialogResult = DialogResult.Cancel;
            var edit = Btn(Tr("edit"), false, 100, 38);
            edit.Location = new Point(close.Left - P(10) - edit.Width, close.Top);
            edit.Click += (s, e) => { wantEdit = true; f.DialogResult = DialogResult.OK; };

            f.Controls.AddRange(new Control[] { lblCat, title, lblWhen, lblNotes, tbNotes, edit, close });
            f.AcceptButton = close;
            f.CancelButton = close;
            f.ShowDialog(this);
            f.Dispose();

            if (wantEdit) OpenEditor(t);   // the Edit button opens the normal editor
        }

        void Toggle(TaskItem t)
        {
            t.Done = !t.Done;
            if (!t.Done && t.RemindAt > DateTime.Now) t.Reminded = false;
            Changed();
        }

        void DeleteTask(TaskItem t)
        {
            if (MessageBox.Show(this, Tr("confirm_del"), "Week Planner", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
            tasks.Remove(t);
            Changed();
        }

        ContextMenuStrip NewMenu()
        {
            return new ContextMenuStrip
            {
                Renderer = new ToolStripProfessionalRenderer(new DarkColors()) { RoundedEdges = false },
                ShowImageMargin = false,
                BackColor = cCard,
                ForeColor = cText,
                Font = F(9.5f)
            };
        }

        void ShowContext(TaskItem t, Point screenPoint)
        {
            var m = NewMenu();
            m.Items.Add(Tr("edit"), null, (s, e) => OpenEditor(t));
            m.Items.Add(t.Done ? Tr("mark_open") : Tr("mark_done"), null, (s, e) => Toggle(t));
            m.Items.Add(new ToolStripSeparator());
            m.Items.Add(Tr("delete"), null, (s, e) => DeleteTask(t));
            m.Show(screenPoint);
        }

        void OpenSettings()
        {
            SettingsDialog();
            SaveData();
            BuildTrayMenu();
            RefreshAll();
        }

        // =================================================================== dialogs
        static readonly Color[] Palette =
        {
            Color.FromArgb(124, 92, 255), Color.FromArgb(56, 189, 248), Color.FromArgb(251, 191, 36),
            Color.FromArgb(74, 222, 128), Color.FromArgb(244, 114, 182), Color.FromArgb(251, 113, 133),
            Color.FromArgb(45, 212, 191), Color.FromArgb(251, 146, 60), Color.FromArgb(163, 230, 53),
            Color.FromArgb(148, 163, 184)
        };

        Form NewDialog(string title, int w, int h)
        {
            var f = new Form
            {
                Text = title,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                MaximizeBox = false,
                MinimizeBox = false,
                ShowInTaskbar = false,
                StartPosition = FormStartPosition.CenterParent,
                BackColor = cSide,
                ForeColor = cText,
                Font = F(9.5f),
                AutoScaleMode = AutoScaleMode.None
            };
            f.ClientSize = new Size(P(w), P(h));
            DarkBar(f);
            return f;
        }

        static Panel Row(string label, Control c, int h)
        {
            var p = new Panel { Width = P(400), Height = P(h), Margin = new Padding(0, 0, 0, P(2)), BackColor = Color.Transparent };
            var l = Lbl(label, 9f, cMuted);
            l.Location = new Point(0, 0);
            c.Location = new Point(0, P(22));
            c.Width = P(400);
            p.Controls.Add(l);
            p.Controls.Add(c);
            return p;
        }

        bool TaskDialog(TaskItem task, bool isNew, out bool deleted)
        {
            bool del = false;
            var f = NewDialog(Tr(isNew ? "new_task_title" : "edit_task"), 440, 540);
            var flow = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.TopDown,
                WrapContents = false,
                Padding = new Padding(P(20), P(14), P(20), 0),
                BackColor = cSide
            };
            var bottom = new Panel { Dock = DockStyle.Bottom, Height = P(70), BackColor = cSide };
            f.Controls.Add(flow);
            f.Controls.Add(bottom);

            // title
            var tbTitle = Input(false);
            tbTitle.Text = task.Title ?? "";
            flow.Controls.Add(Row(Tr("f_title"), tbTitle, 58));

            // category
            var cbCat = Combo();
            cbCat.DataSource = cats.ToList();
            cbCat.DisplayMember = "Name";
            cbCat.SelectedItem = Cat(task.CategoryId);
            flow.Controls.Add(Row(Tr("f_cat"), cbCat, 58));

            // subject (only shown for categories that ask for it, e.g. School)
            var cbSub = Combo();
            cbSub.DropDownStyle = ComboBoxStyle.DropDown;
            var rowSub = Row(Tr("f_subject"), cbSub, 58);
            flow.Controls.Add(rowSub);
            Action fillSubs = () =>
            {
                var c = (Category)cbCat.SelectedItem;
                if (c == null) return;
                rowSub.Visible = c.AsksSubject;
                cbSub.Items.Clear();
                cbSub.Items.AddRange(c.Subjects.Cast<object>().ToArray());
            };
            fillSubs();
            cbSub.Text = task.Subject ?? "";
            cbCat.SelectedIndexChanged += (s, e) => { fillSubs(); cbSub.Text = ""; };

            // due date + time
            var due = new Panel { Height = P(30), BackColor = Color.Transparent };
            var dtDate = new DateTimePicker
            {
                Format = DateTimePickerFormat.Custom,
                CustomFormat = "ddd  dd.MM.yyyy",
                Font = F(10f),
                Width = P(210),
                Location = new Point(0, 0),
                Value = task.Due,
                CalendarMonthBackground = cCard,
                CalendarForeColor = cText,
                CalendarTitleBackColor = cAccent,
                CalendarTitleForeColor = Color.White,
                CalendarTrailingForeColor = cMuted
            };
            var dtTime = new DateTimePicker
            {
                Format = DateTimePickerFormat.Custom,
                CustomFormat = "HH:mm",
                ShowUpDown = true,
                Font = F(10f),
                Width = P(110),
                Location = new Point(P(222), 0),
                Value = task.Due
            };
            due.Controls.Add(dtDate);
            due.Controls.Add(dtTime);
            flow.Controls.Add(Row(Tr("f_due"), due, 58));

            // reminder
            var rem = new Panel { Height = P(30), BackColor = Color.Transparent };
            var chkRem = new CheckBox { Text = Tr("f_remind"), AutoSize = true, ForeColor = cText, Location = new Point(0, P(4)), Checked = task.RemindEnabled, BackColor = Color.Transparent };
            var nudRem = new NumericUpDown
            {
                Minimum = 1,
                Maximum = 999,
                Value = Math.Max(1, Math.Min(999, task.RemindAmount)),
                Width = P(60),
                Location = new Point(P(124), 0),
                BackColor = cCard,
                ForeColor = cText,
                Font = F(10f),
                BorderStyle = BorderStyle.FixedSingle
            };
            var cbUnit = Combo();
            cbUnit.Items.AddRange(new object[] { Tr("u_minutes"), Tr("u_hours"), Tr("u_days") });
            cbUnit.SelectedIndex = Math.Max(0, Math.Min(2, task.RemindUnit));
            cbUnit.Location = new Point(P(192), 0);
            cbUnit.Width = P(110);
            var lblBefore = Lbl(Tr("before"), 9.5f, cSoft);
            lblBefore.Location = new Point(P(310), P(5));
            rem.Controls.AddRange(new Control[] { chkRem, nudRem, cbUnit, lblBefore });
            Action sync = () => { nudRem.Enabled = chkRem.Checked; cbUnit.Enabled = chkRem.Checked; };
            chkRem.CheckedChanged += (s, e) => sync();
            sync();
            flow.Controls.Add(Row(Tr("reminder"), rem, 58));

            // notes
            var tbNotes = Input(true);
            tbNotes.Height = P(64);
            tbNotes.Text = task.Notes ?? "";
            flow.Controls.Add(Row(Tr("f_notes"), tbNotes, 92));

            // buttons
            var save = Btn(Tr("save"), true, 110, 38);
            save.Location = new Point(P(440) - P(20) - save.Width, P(16));
            var cancel = Btn(Tr("cancel"), false, 100, 38);
            cancel.Location = new Point(save.Left - P(10) - cancel.Width, P(16));
            cancel.DialogResult = DialogResult.Cancel;
            bottom.Controls.Add(save);
            bottom.Controls.Add(cancel);

            save.Click += (s, e) =>
            {
                string title = tbTitle.Text.Trim();
                if (title == "")
                {
                    MessageBox.Show(f, Tr("title_required"), f.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    tbTitle.Focus();
                    return;
                }
                var cat = (Category)cbCat.SelectedItem;
                string sub = cat.AsksSubject ? cbSub.Text.Trim() : "";
                if (sub != "" && !cat.Subjects.Any(x => string.Equals(x, sub, StringComparison.OrdinalIgnoreCase)))
                    cat.Subjects.Add(sub);

                var newDue = dtDate.Value.Date + dtTime.Value.TimeOfDay;
                bool timingChanged = isNew || task.Due != newDue || task.RemindEnabled != chkRem.Checked
                                     || task.RemindAmount != (int)nudRem.Value || task.RemindUnit != cbUnit.SelectedIndex;

                task.Title = title;
                task.CategoryId = cat.Id;
                task.Subject = sub;
                task.Due = newDue;
                task.Notes = tbNotes.Text.Trim();
                task.RemindEnabled = chkRem.Checked;
                task.RemindAmount = (int)nudRem.Value;
                task.RemindUnit = cbUnit.SelectedIndex;
                if (timingChanged)
                {
                    task.SnoozeUntil = DateTime.MinValue;
                    task.Reminded = task.RemindEnabled && task.Due <= DateTime.Now;   // don't fire for tasks already in the past
                }
                f.DialogResult = DialogResult.OK;
            };

            if (!isNew)
            {
                var delBtn = Btn(Tr("delete"), false, 90, 38);
                delBtn.ForeColor = cDanger;
                delBtn.Location = new Point(P(20), P(16));
                delBtn.Click += (s, e) =>
                {
                    if (MessageBox.Show(f, Tr("confirm_del"), f.Text, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        del = true;
                        f.DialogResult = DialogResult.OK;
                    }
                };
                bottom.Controls.Add(delBtn);
            }
            f.AcceptButton = save;
            f.CancelButton = cancel;

            bool ok = f.ShowDialog(this) == DialogResult.OK;
            f.Dispose();
            deleted = del;
            return ok;
        }

        bool CategoryDialog(Category c, bool isNew)
        {
            var f = NewDialog(Tr("cat_title"), 440, 430);
            Color chosen = isNew ? Palette[cats.Count % Palette.Length] : c.Col;

            var l1 = Lbl(Tr("name"), 9f, cMuted); l1.Location = new Point(P(20), P(16));
            var tbName = Input(false); tbName.Location = new Point(P(20), P(38)); tbName.Width = P(400);
            tbName.Text = isNew ? "" : c.Name;

            var l2 = Lbl(Tr("color"), 9f, cMuted); l2.Location = new Point(P(20), P(86));
            var swatches = new List<Panel>();
            for (int i = 0; i < Palette.Length; i++)
            {
                var sw = new Panel { Size = new Size(P(32), P(32)), Location = new Point(P(20) + i * P(40), P(110)), Cursor = Cursors.Hand, BackColor = cSide, Tag = Palette[i] };
                sw.Paint += (s, e) =>
                {
                    var g = e.Graphics;
                    g.SmoothingMode = SmoothingMode.AntiAlias;
                    var col = (Color)((Panel)s).Tag;
                    Dot(g, col, new Rectangle(P(4), P(4), P(24), P(24)));
                    if (col.ToArgb() == chosen.ToArgb())
                        using (var pen = new Pen(Color.White, 2f)) g.DrawEllipse(pen, P(1), P(1), P(29), P(29));
                };
                sw.Click += (s, e) => { chosen = (Color)((Panel)s).Tag; foreach (var x in swatches) x.Invalidate(); };
                swatches.Add(sw);
                f.Controls.Add(sw);
            }

            var chkAsk = new CheckBox { Text = Tr("ask_subject"), AutoSize = true, ForeColor = cText, Location = new Point(P(20), P(166)), Checked = c.AsksSubject, BackColor = Color.Transparent };
            var lblSubs = Lbl(Tr("subjects_hint"), 9f, cMuted); lblSubs.Location = new Point(P(20), P(200));
            var tbSubs = Input(true); tbSubs.Location = new Point(P(20), P(222)); tbSubs.Size = new Size(P(400), P(110));
            tbSubs.Text = string.Join(", ", c.Subjects.ToArray());
            Action sync = () => { lblSubs.Visible = chkAsk.Checked; tbSubs.Visible = chkAsk.Checked; };
            chkAsk.CheckedChanged += (s, e) => sync();
            sync();

            var save = Btn(Tr("save"), true, 110, 38); save.Location = new Point(P(440) - P(20) - save.Width, P(430) - P(58));
            var cancel = Btn(Tr("cancel"), false, 100, 38); cancel.Location = new Point(save.Left - P(10) - cancel.Width, save.Top);
            cancel.DialogResult = DialogResult.Cancel;
            save.Click += (s, e) =>
            {
                string name = tbName.Text.Trim();
                if (name == "") { MessageBox.Show(f, Tr("name_required"), f.Text); return; }
                if (isNew) c.Id = Guid.NewGuid().ToString("N");
                if (name != c.Name) c.CustomName = name;
                c.Rgb = chosen.ToArgb();
                c.AsksSubject = chkAsk.Checked;
                c.Subjects = tbSubs.Text.Split(new[] { ',', ';', '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries)
                                   .Select(x => x.Trim()).Where(x => x != "").Distinct().ToList();
                f.DialogResult = DialogResult.OK;
            };

            f.Controls.AddRange(new Control[] { l1, tbName, l2, chkAsk, lblSubs, tbSubs, save, cancel });
            f.AcceptButton = save;
            f.CancelButton = cancel;
            bool ok = f.ShowDialog(this) == DialogResult.OK;
            f.Dispose();
            return ok;
        }

        void SettingsDialog()
        {
            var f = NewDialog(Tr("settings"), 440, 560);
            int x = P(20);

            var l1 = Lbl(Tr("s_lang"), 9f, cMuted); l1.Location = new Point(x, P(18));
            var cbLang = Combo();
            cbLang.Items.AddRange(new object[] { "English", "Deutsch" });
            cbLang.SelectedIndex = lang == "de" ? 1 : 0;
            cbLang.Location = new Point(x, P(40)); cbLang.Width = P(200);

            var chkAuto = new CheckBox { Text = Tr("s_auto"), AutoSize = true, ForeColor = cText, Location = new Point(x, P(88)), Checked = AutoStartEnabled(), BackColor = Color.Transparent };
            chkAuto.CheckedChanged += (s, e) => SetAutoStart(chkAuto.Checked);

            var l2 = Lbl(Tr("s_cats"), 9f, cMuted); l2.Location = new Point(x, P(132));
            var lb = new ListBox
            {
                Location = new Point(x, P(156)),
                Size = new Size(P(400), P(280)),
                BorderStyle = BorderStyle.None,
                BackColor = cCard,
                ForeColor = cText,
                DrawMode = DrawMode.OwnerDrawFixed,
                ItemHeight = P(36)
            };
            lb.DrawItem += (s, e) =>
            {
                if (e.Index < 0) return;
                var g = e.Graphics;
                g.SmoothingMode = SmoothingMode.AntiAlias;
                using (var b = new SolidBrush((e.State & DrawItemState.Selected) != 0 ? cHover : cCard)) g.FillRectangle(b, e.Bounds);
                var c = (Category)lb.Items[e.Index];
                Dot(g, c.Col, new Rectangle(e.Bounds.X + P(14), e.Bounds.Y + (e.Bounds.Height - P(12)) / 2, P(12), P(12)));
                Txt(g, c.Name, F(10f), new Rectangle(e.Bounds.X + P(38), e.Bounds.Y, e.Bounds.Width - P(50), e.Bounds.Height), cText);
            };
            Action reload = () =>
            {
                int sel = lb.SelectedIndex;
                lb.Items.Clear();
                foreach (var c in cats) lb.Items.Add(c);
                if (lb.Items.Count > 0) lb.SelectedIndex = Math.Max(0, Math.Min(sel, lb.Items.Count - 1));
            };
            reload();
            cbLang.SelectedIndexChanged += (s, e) => { SetLang(cbLang.SelectedIndex == 1 ? "de" : "en"); lb.Invalidate(); };

            var add = Btn(Tr("add"), false, 100, 36); add.Location = new Point(x, P(448));
            var edit = Btn(Tr("edit"), false, 100, 36); edit.Location = new Point(x + P(108), P(448));
            var del = Btn(Tr("delete"), false, 100, 36); del.Location = new Point(x + P(216), P(448)); del.ForeColor = cDanger;
            Action editSel = () =>
            {
                var c = lb.SelectedItem as Category;
                if (c != null && CategoryDialog(c, false)) reload();
            };
            add.Click += (s, e) =>
            {
                var c = new Category();
                if (CategoryDialog(c, true)) { cats.Add(c); reload(); }
            };
            edit.Click += (s, e) => editSel();
            lb.DoubleClick += (s, e) => editSel();
            del.Click += (s, e) =>
            {
                var c = lb.SelectedItem as Category;
                if (c == null) return;
                if (cats.Count <= 1) { MessageBox.Show(f, Tr("keep_one"), f.Text); return; }
                if (MessageBox.Show(f, Tr("confirm_cat_del"), f.Text, MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
                tasks.RemoveAll(t => t.CategoryId == c.Id);
                cats.Remove(c);
                reload();
            };

            var close = Btn(Tr("close"), true, 110, 38);
            close.Location = new Point(P(440) - x - close.Width, P(560) - P(58));
            close.DialogResult = DialogResult.OK;
            f.AcceptButton = close;

            f.Controls.AddRange(new Control[] { l1, cbLang, chkAuto, l2, lb, add, edit, del, close });
            f.ShowDialog(this);
            f.Dispose();
        }

        // =================================================================== reminders
        static readonly List<Popup> popups = new List<Popup>();

        static void RelayoutPopups()
        {
            var wa = Screen.PrimaryScreen.WorkingArea;
            int y = wa.Bottom - P(16);
            foreach (var p in popups)
            {
                y -= p.Height;
                p.Location = new Point(wa.Right - p.Width - P(16), y);
                y -= P(10);
            }
        }

        static void ShowReminder(TaskItem t, Action onDone, Action onSnooze)
        {
            var p = new Popup
            {
                AutoScaleMode = AutoScaleMode.None,
                FormBorderStyle = FormBorderStyle.None,
                ShowInTaskbar = false,
                TopMost = true,
                StartPosition = FormStartPosition.Manual,
                BackColor = cCard,
                ForeColor = cText,
                Font = F(9.5f),
                Accent = Cat(t.CategoryId).Col
            };
            p.Size = new Size(P(390), P(160));

            var head = Lbl(Tr("reminder").ToUpper(cul), 8f, p.Accent, FontStyle.Bold); head.Location = new Point(P(24), P(14));
            var title = new Label
            {
                Text = t.Title,
                Font = F(12.5f, FontStyle.Bold),
                ForeColor = cText,
                BackColor = Color.Transparent,
                AutoEllipsis = true,
                Location = new Point(P(24), P(36)),
                Size = new Size(P(350), P(28))
            };
            string detail = string.Format(Tr("due_at"), t.Due.ToString("ddd d MMM, HH:mm", cul));
            if (!string.IsNullOrWhiteSpace(t.Subject)) detail += "  ·  " + t.Subject;
            var sub = new Label
            {
                Text = detail,
                Font = F(9.5f),
                ForeColor = cSoft,
                BackColor = Color.Transparent,
                AutoEllipsis = true,
                Location = new Point(P(24), P(66)),
                Size = new Size(P(350), P(22))
            };

            var done = Btn(Tr("done"), true, 96, 36); done.Location = new Point(P(24), P(104));
            var snooze = Btn(Tr("snooze"), false, 140, 36); snooze.Location = new Point(P(130), P(104));
            var dismiss = Btn(Tr("dismiss"), false, 90, 36); dismiss.Location = new Point(P(280), P(104));
            done.TabStop = false; snooze.TabStop = false; dismiss.TabStop = false;
            done.Click += (s, e) => { onDone(); p.Close(); };
            snooze.Click += (s, e) => { onSnooze(); p.Close(); };
            dismiss.Click += (s, e) => p.Close();

            p.Controls.AddRange(new Control[] { head, title, sub, done, snooze, dismiss });
            p.FormClosed += (s, e) => { popups.Remove(p); RelayoutPopups(); };
            popups.Add(p);
            RelayoutPopups();
            p.Show();
        }

        void OnTick()
        {
            CheckReminders();

            var now = DateTime.Now;
            var next = tasks.Where(t => !t.Done && t.Due >= now).OrderBy(t => t.Due).FirstOrDefault();
            tray.Text = next == null ? Tr("app_title") : Cut(Tr("next") + next.Title + " · " + Rel(next.Due), 60);

            if (now.Minute != lastMinute)
            {
                lastMinute = now.Minute;
                RefreshAll();
            }
        }

        void CheckReminders()
        {
            var now = DateTime.Now;
            bool changed = false;
            foreach (var t in tasks.ToList())
            {
                if (t.Done || !t.RemindEnabled || t.Reminded) continue;
                if (t.RemindAt > now) continue;
                t.Reminded = true;
                t.SnoozeUntil = DateTime.MinValue;
                changed = true;
                if (t.Due < now.AddDays(-2)) continue;   // very old, skip silently
                Notify(t);
            }
            if (changed) SaveData();
        }

        void Notify(TaskItem t)
        {
            SystemSounds.Exclamation.Play();
            string when = string.Format(Tr("due_at"), t.Due.ToString("ddd d MMM, HH:mm", cul));
            tray.ShowBalloonTip(8000, Tr("reminder") + ": " + t.Title, when, ToolTipIcon.Info);

            var ignore = SendEmailReminderAsync(t.Title, t.Notes, t.Due);   // e-mail, fire and forget

            ShowReminder(t,
                () => { t.Done = true; Changed(); },
                () => { t.Reminded = false; t.SnoozeUntil = DateTime.Now.AddMinutes(10); SaveData(); });
        }

        // =================================================================== tray + window behaviour
        void BuildTray()
        {
            tray = new NotifyIcon { Icon = appIcon, Text = Tr("app_title"), Visible = true };
            tray.DoubleClick += (s, e) => ShowMain();
            BuildTrayMenu();
        }

        void BuildTrayMenu()
        {
            var m = NewMenu();
            m.Items.Add(Tr("open"), null, (s, e) => ShowMain());
            m.Items.Add(Tr("new_task").Replace("+", "").Trim(), null, (s, e) => { ShowMain(); NewTask(null); });
            m.Items.Add(new ToolStripSeparator());
            m.Items.Add(Tr("exit"), null, (s, e) => ExitApp());
            var old = tray.ContextMenuStrip;
            tray.ContextMenuStrip = m;
            if (old != null) old.Dispose();
        }

        void ShowMain()
        {
            startHidden = false;
            Show();
            if (WindowState == FormWindowState.Minimized) WindowState = FormWindowState.Normal;
            Activate();
        }

        void ExitApp()
        {
            exiting = true;
            foreach (var p in popups.ToList()) p.Close();
            Close();
        }

        protected override void SetVisibleCore(bool value)
        {
            if (startHidden)
            {
                if (!IsHandleCreated) CreateHandle();
                value = false;
            }
            base.SetVisibleCore(value);
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (!exiting && e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true;
                Hide();
                if (!trayHint)
                {
                    trayHint = true;
                    SaveData();
                    tray.ShowBalloonTip(5000, Tr("app_title"), Tr("tray_hint"), ToolTipIcon.Info);
                }
                return;
            }
            base.OnFormClosing(e);
        }

        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            if (timer != null) timer.Stop();
            if (tray != null) { tray.Visible = false; tray.Dispose(); }
            try { if (instanceMutex != null) instanceMutex.ReleaseMutex(); } catch { }
            base.OnFormClosed(e);
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == (Keys.Control | Keys.N)) { NewTask(null); return true; }
            if (mode == ViewMode.Week && !(ActiveControl is TextBox))
            {
                if (keyData == Keys.Left) { weekOffset--; wScroll = 0; RefreshAll(); return true; }
                if (keyData == Keys.Right) { weekOffset++; wScroll = 0; RefreshAll(); return true; }
                if (keyData == Keys.Home) { weekOffset = 0; wScroll = 0; RefreshAll(); return true; }
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        protected override void OnMouseWheel(MouseEventArgs e)
        {
            base.OnMouseWheel(e);
            var vp = mode == ViewMode.Week ? weekP : listP;
            if (vp == null || !vp.RectangleToScreen(vp.ClientRectangle).Contains(Cursor.Position)) return;
            int d = e.Delta * P(70) / 120;
            if (mode == ViewMode.Week) { wScroll = Math.Max(0, Math.Min(wMax, wScroll - d)); weekP.Invalidate(); }
            else { lScroll = Math.Max(0, Math.Min(lMax, lScroll - d)); listP.Invalidate(); }
        }
    }
}