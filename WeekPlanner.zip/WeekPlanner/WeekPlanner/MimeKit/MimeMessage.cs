﻿// =====================================================================================
//  WEEK PLANNER  -  everything lives in this one file (Form1).
//  Works with a normal .NET Framework WinForms project (4.5 - 4.8), C# 7.3.
//  NuGet package needed: MailKit   (Install-Package MailKit)
//  If your project's namespace is not "WeekPlanner", just change the line below
//  (and in Form1.Designer.cs / Program.cs).
// =====================================================================================
namespace MimeKit
{
    internal class MimeMessage
    {
        public MimeMessage()
        {
        }
    }
}